<?php

$lang = array(

#torrenttable

'torrenttable_type' 		=> 'Type', 
'torrenttable_name' 		=> 'Name', 
'torrenttable_dl' 		=> 'DL', 
'torrenttable_wait' 		=> 'Wait', 
'torrenttable_edit' 		=> 'Edit', 
'torrenttable_visible' 		=> 'Visible', 
'torrenttable_files' 		=> 'Files', 
'torrenttable_comments' 	=> 'Comm.', 
'torrenttable_rating' 		=> 'Rating',
'torrenttable_added' 		=> 'Added',
'torrenttable_ttl' 		=> 'TTL',
'torrenttable_size' 		=> 'Size', 
'torrenttable_views' 		=> 'Views', 
'torrenttable_hits' 		=> 'Hits', 
'torrenttable_snatched' 	=> 'Snatched', 
'torrenttable_seeders' 		=> 'Seeders', 
'torrenttable_leechers' 	=> 'Leechers', 
'torrenttable_uppedby' 		=> 'Upped&nbsp;by', 
'torrenttable_wait_h' 		=> 'h', 
'torrenttable_wait_none' 	=> 'None', 
'torrenttable_view_nfo_alt' 	=> 'View NFO', 
'torrenttable_download_alt' 	=> 'Download', 
'torrenttable_edit' 		=> 'Edit', 
'torrenttable_not_visible' 	=> 'No', 
'torrenttable_visible' 		=> 'Yes', 
'torrenttable_hour_singular' 	=> 'hour', 
'torrenttable_hour_plural' 	=> 'hours', 
'torrenttable_time_singular' 	=> 'time', 
'torrenttable_time_plural' 	=> 'times', 
'torrenttable_unknown_uploader' => 'unknown', 

#commenttable

'commenttable_by' 		=> 'by', 
'commenttable_donor_alt' 	=> 'Donor', 
'commenttable_warned_alt' 	=> 'Warned', 
'commenttable_orphaned' 	=> 'orphaned', 
'commenttable_edit' 		=> 'Edit', 
'commenttable_delete' 		=> 'Delete', 
'commenttable_view_original' 	=> 'View Original', 
'commenttable_last_edited_by' 	=> 'Last edited by', 
'commenttable_last_edited_at' 	=> 'at'
);

?>