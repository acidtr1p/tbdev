<?php

$lang = array(

#Browse
'browse_error' => "Error",
'browse_invalid_cat' => "Invalid category ID.",
'browse_search' => "Search results for ",
'browse_show_all' => "Show all",
'browse_active' => "active",
'browse_inc_dead' => "including dead",
'browse_dead' => "only dead",
'browse_go' => "Go!",
'browse_search' => "Search results for ",
'browse_not_found' => "Nothing found!",
'browse_tryagain' => "Try again with a refined search string.",
'browse_nothing' => "Nothing here!",
'browse_sorry' => "Sorry pal :",


);

?>