<?php

$lang = array(

#Download
'download_user_error' => "USER ERROR",
'download_no_id' => "No torrent with that ID exists",


);

?>