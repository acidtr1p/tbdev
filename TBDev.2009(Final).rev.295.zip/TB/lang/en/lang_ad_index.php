<?php
//admin index lang file
$lang = array(
'index_bans' => 'Bans',
'index_new_user' => 'Add user',
'index_log' => 'Logs',
'index_mcleanup' => 'Manual cleanup',
'index_user_list' => 'Users list',
'index_tags' => 'Tags',
'index_emoticons' => 'Emoticons',
'index_delacct' => 'Delete account',
'index_stats' => 'Tracker stats',
'index_testip' => 'Test Ip',
'index_user_search' => 'User search',
'index_mysql_overview' => 'Mysql Overview',
'index_mysql_stats' => 'Mysql Stats',
'index_stats_extra' => 'Stats Extra',
'index_forummanage' => 'Forum manage',
'index_categories' => 'Edit categories',
'index_newusers' => 'New users',
'index_resetpassword' => 'Reset password',
'index_rep_system' => 'Reputation system',
'index_rep_settings' => 'Reputation settings',
'index_news' => 'Add/Delete News'
);
?>