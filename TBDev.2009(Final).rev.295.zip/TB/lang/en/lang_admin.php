<?php

$lang = array(

#Admin
'admin_user_error' => "USER ERROR",
'admin_unexpected' => "You got here unexpectedly!",

);

?>