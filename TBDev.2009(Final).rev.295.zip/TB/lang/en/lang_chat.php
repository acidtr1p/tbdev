<?php

$lang = array(

#Chat
'chat_channel' => "The official IRC channel is ",
'chat_on' => " on the ",
'chat_network' => "network.",
'chat_chat' => "Chat",


);

?>