<?php

$lang = array(

#Misc
'stdhead_staff' => "Staff",

#Texts
'text_none' => "None defined yet...",
'text_staff' => "Staff page",
'alt_pm' => "Personal Message",
'alt_sm' => "Send Mail",

#The table
'header_sysops' => "Sysops",
'header_admins' => "Administrators",
'header_mods' => "Moderators",
'header_vips' => "VIP's"
);

?>
