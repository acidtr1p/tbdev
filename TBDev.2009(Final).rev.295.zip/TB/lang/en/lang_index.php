<?php

$lang = array(

#News
'news_title'	=> "Recent News",
'news_link' => "News Page",
'news_edit' 		    => "Edit",
'news_delete' 			=> "Delete",

#Stats
'stats_title' 			=> "Stats",
'stats_regusers' 			=> "Registered Users",
'stats_unverified' 				=> "Unconfirmed Users",
'stats_torrents' 			=> "Torrents",
'stats_peers' => "Peers",
'stats_seed' 			=> "Seeders",
'stats_leech' 			=> "Leechers",
'stats_sl_ratio' 				=> "Seeder/leecher ratio (%)",

#disclaimer
'foot_disclaimer' 			=> "Disclaimer: None of the files shown here are actually hosted on this server. The links are provided solely by this site's users.
The administrator of this site (%s) cannot be held responsible for what its users post, or any other actions of its users.
You may not use this site to distribute or download any material when you do not have the legal rights to do so.
It is your own responsibility to adhere to these terms."

);

?>