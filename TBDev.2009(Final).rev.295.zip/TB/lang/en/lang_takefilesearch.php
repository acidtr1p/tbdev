<?php

$lang = array(

'tstdhead' => "Torrent internal file search",

#takefilesearch errors
'tfilesearch_oops' => "Oops",
'tfilesearch_nuffin' => "Nuffin 'ere!",
'tfilesearch_error' => "Error",
'tfilesearch_nothing' => "Nothing Found.",
#filesearch table
'tID' => "ID",
'tfilename' => "Filename",
'tscore' => "Relevance",
);

?>