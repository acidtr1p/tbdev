<?php

$lang = array(

#Mytorrents
'mytorrents_no_torrents' => "<h1>No torrents</h1>",
'mytorrents_no_uploads' => "<p>You haven't uploaded any torrents yet, so there's nothing in this page.</p>",

);

?>