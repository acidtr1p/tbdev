<?php

$lang = array(

#takelogin errors
'tlogin_failed' => "Login failed!",
'tlogin_disabled' => "This account has been disabled.",
'tlogin_no_access' => "Access denied."
);

?>