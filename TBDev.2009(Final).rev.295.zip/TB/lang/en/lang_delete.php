<?php

$lang = array(

#Delete
'delete_failed' => "Delete failed!",
'delete_missing_data' => "missing form data",
'delete_not_exist' => "Torrent does not exist",
'delete_not_owner' => "You're not the owner! How did that happen?",
'delete_invalid' => "Invalid reason",
'delete_dead' => "Dead: 0 seeders, 0 leechers = 0 peers totalDead: 0 seeders, 0 leechers = 0 peers total",
'delete_dupe' => "Dupe",
'delete_nuked' => "Nuked",
'delete_violated' => "Please describe the violated rule.",
'delete_reason' => "Please enter the reason for deleting this torrent.",
'delete_rules' => " rules broken: ",
'delete_go_back' => "Go back to whence you came",
'delete_back_index' => "Back to index",
'delete_deleted' => "Torrent deleted!",
'delete_torrent' => "Torrent ",
'delete_deleted_by' => " was deleted by ",

);

?>