<?php

$lang = array(

#Confirmmail
'confirmmail_user_error' => "USER ERROR",
'confirmmail_idiot' => "Idiot, no data!",
'confirmmail_no_key' => "No key set",
'confirmmail_no-id' => "No id set",
'confirmmail_false_email' => "Not a real email address!",
'confirmmail_not_complete' => "Cannot complete",


);

?>