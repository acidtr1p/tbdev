-- phpMyAdmin SQL Dump
-- version 2.9.2
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Oct 27, 2009 at 10:12 PM
-- Server version: 5.0.33
-- PHP Version: 5.2.1
-- 
-- Database: `tb`
-- 

-- 
-- Dumping data for table `categories`
-- 

INSERT INTO `categories` VALUES (1, 'Appz/PC ISO', 'cat_apps.gif', 'No Description');
INSERT INTO `categories` VALUES (2, 'Games/PC ISO', 'cat_games.gif', 'No Description');
INSERT INTO `categories` VALUES (3, 'Movies/SVCD', 'cat_movies.gif', 'No Description');
INSERT INTO `categories` VALUES (4, 'Music', 'cat_music.gif', 'No Description');
INSERT INTO `categories` VALUES (5, 'Episodes', 'cat_episodes.gif', 'No Description');
INSERT INTO `categories` VALUES (6, 'XXX', 'cat_xxx.gif', 'No Description');
INSERT INTO `categories` VALUES (7, 'Games/GBA', 'cat_games.gif', 'No Description');
INSERT INTO `categories` VALUES (8, 'Games/PS2', 'cat_games.gif', 'No Description');
INSERT INTO `categories` VALUES (9, 'Anime', 'cat_anime.gif', 'No Description');
INSERT INTO `categories` VALUES (10, 'Movies/XviD', 'cat_movies.gif', 'No Description');
INSERT INTO `categories` VALUES (11, 'Movies/DVD-R', 'cat_movies.gif', 'No Description');
INSERT INTO `categories` VALUES (12, 'Games/PC Rips', 'cat_games.gif', 'No Description');
INSERT INTO `categories` VALUES (13, 'Appz/misc', 'cat_apps.gif', 'No Description');
