INSERT INTO `avps` VALUES 
('lastcleantime', '', 0, 1247059621),
('seeders', '', 0, 1),
('leechers', '', 0, 0),
('loadlimit', '12.5-1246045258', 0, 0);