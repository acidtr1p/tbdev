-- phpMyAdmin SQL Dump
-- version 2.9.2
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Jan 05, 2008 at 01:03 PM
-- Server version: 5.0.33
-- PHP Version: 5.2.1
-- 
-- Database: `tb`
-- 

-- 
-- Dumping data for table `countries`
-- 

INSERT INTO `countries` VALUES (1, 'Sweden', 'sweden.gif');
INSERT INTO `countries` VALUES (2, 'United States of America', 'usa.gif');
INSERT INTO `countries` VALUES (3, 'Russia', 'russia.gif');
INSERT INTO `countries` VALUES (4, 'Finland', 'finland.gif');
INSERT INTO `countries` VALUES (5, 'Canada', 'canada.gif');
INSERT INTO `countries` VALUES (6, 'France', 'france.gif');
INSERT INTO `countries` VALUES (7, 'Germany', 'germany.gif');
INSERT INTO `countries` VALUES (8, 'China', 'china.gif');
INSERT INTO `countries` VALUES (9, 'Italy', 'italy.gif');
INSERT INTO `countries` VALUES (10, 'Denmark', 'denmark.gif');
INSERT INTO `countries` VALUES (11, 'Norway', 'norway.gif');
INSERT INTO `countries` VALUES (12, 'United Kingdom', 'uk.gif');
INSERT INTO `countries` VALUES (13, 'Ireland', 'ireland.gif');
INSERT INTO `countries` VALUES (14, 'Poland', 'poland.gif');
INSERT INTO `countries` VALUES (15, 'Netherlands', 'netherlands.gif');
INSERT INTO `countries` VALUES (16, 'Belgium', 'belgium.gif');
INSERT INTO `countries` VALUES (17, 'Japan', 'japan.gif');
INSERT INTO `countries` VALUES (18, 'Brazil', 'brazil.gif');
INSERT INTO `countries` VALUES (19, 'Argentina', 'argentina.gif');
INSERT INTO `countries` VALUES (20, 'Australia', 'australia.gif');
INSERT INTO `countries` VALUES (21, 'New Zealand', 'newzealand.gif');
INSERT INTO `countries` VALUES (22, 'Spain', 'spain.gif');
INSERT INTO `countries` VALUES (23, 'Portugal', 'portugal.gif');
INSERT INTO `countries` VALUES (24, 'Mexico', 'mexico.gif');
INSERT INTO `countries` VALUES (25, 'Singapore', 'singapore.gif');
INSERT INTO `countries` VALUES (67, 'India', 'india.gif');
INSERT INTO `countries` VALUES (62, 'Albania', 'albania.gif');
INSERT INTO `countries` VALUES (26, 'South Africa', 'southafrica.gif');
INSERT INTO `countries` VALUES (27, 'South Korea', 'southkorea.gif');
INSERT INTO `countries` VALUES (28, 'Jamaica', 'jamaica.gif');
INSERT INTO `countries` VALUES (29, 'Luxembourg', 'luxembourg.gif');
INSERT INTO `countries` VALUES (30, 'Hong Kong', 'hongkong.gif');
INSERT INTO `countries` VALUES (31, 'Belize', 'belize.gif');
INSERT INTO `countries` VALUES (32, 'Algeria', 'algeria.gif');
INSERT INTO `countries` VALUES (33, 'Angola', 'angola.gif');
INSERT INTO `countries` VALUES (34, 'Austria', 'austria.gif');
INSERT INTO `countries` VALUES (35, 'Yugoslavia', 'yugoslavia.gif');
INSERT INTO `countries` VALUES (36, 'Western Samoa', 'westernsamoa.gif');
INSERT INTO `countries` VALUES (37, 'Malaysia', 'malaysia.gif');
INSERT INTO `countries` VALUES (38, 'Dominican Republic', 'dominicanrep.gif');
INSERT INTO `countries` VALUES (39, 'Greece', 'greece.gif');
INSERT INTO `countries` VALUES (40, 'Guatemala', 'guatemala.gif');
INSERT INTO `countries` VALUES (41, 'Israel', 'israel.gif');
INSERT INTO `countries` VALUES (42, 'Pakistan', 'pakistan.gif');
INSERT INTO `countries` VALUES (43, 'Czech Republic', 'czechrep.gif');
INSERT INTO `countries` VALUES (44, 'Serbia', 'serbia.gif');
INSERT INTO `countries` VALUES (45, 'Seychelles', 'seychelles.gif');
INSERT INTO `countries` VALUES (46, 'Taiwan', 'taiwan.gif');
INSERT INTO `countries` VALUES (47, 'Puerto Rico', 'puertorico.gif');
INSERT INTO `countries` VALUES (48, 'Chile', 'chile.gif');
INSERT INTO `countries` VALUES (49, 'Cuba', 'cuba.gif');
INSERT INTO `countries` VALUES (50, 'Congo', 'congo.gif');
INSERT INTO `countries` VALUES (51, 'Afghanistan', 'afghanistan.gif');
INSERT INTO `countries` VALUES (52, 'Turkey', 'turkey.gif');
INSERT INTO `countries` VALUES (53, 'Uzbekistan', 'uzbekistan.gif');
INSERT INTO `countries` VALUES (54, 'Switzerland', 'switzerland.gif');
INSERT INTO `countries` VALUES (55, 'Kiribati', 'kiribati.gif');
INSERT INTO `countries` VALUES (56, 'Philippines', 'philippines.gif');
INSERT INTO `countries` VALUES (57, 'Burkina Faso', 'burkinafaso.gif');
INSERT INTO `countries` VALUES (58, 'Nigeria', 'nigeria.gif');
INSERT INTO `countries` VALUES (59, 'Iceland', 'iceland.gif');
INSERT INTO `countries` VALUES (60, 'Nauru', 'nauru.gif');
INSERT INTO `countries` VALUES (61, 'Slovenia', 'slovenia.gif');
INSERT INTO `countries` VALUES (63, 'Turkmenistan', 'turkmenistan.gif');
INSERT INTO `countries` VALUES (64, 'Bosnia Herzegovina', 'bosniaherzegovina.gif');
INSERT INTO `countries` VALUES (65, 'Andorra', 'andorra.gif');
INSERT INTO `countries` VALUES (66, 'Lithuania', 'lithuania.gif');
INSERT INTO `countries` VALUES (68, 'Netherlands Antilles', 'nethantilles.gif');
INSERT INTO `countries` VALUES (69, 'Ukraine', 'ukraine.gif');
INSERT INTO `countries` VALUES (70, 'Venezuela', 'venezuela.gif');
INSERT INTO `countries` VALUES (71, 'Hungary', 'hungary.gif');
INSERT INTO `countries` VALUES (72, 'Romania', 'romania.gif');
INSERT INTO `countries` VALUES (73, 'Vanuatu', 'vanuatu.gif');
INSERT INTO `countries` VALUES (74, 'Vietnam', 'vietnam.gif');
INSERT INTO `countries` VALUES (75, 'Trinidad & Tobago', 'trinidadandtobago.gif');
INSERT INTO `countries` VALUES (76, 'Honduras', 'honduras.gif');
INSERT INTO `countries` VALUES (77, 'Kyrgyzstan', 'kyrgyzstan.gif');
INSERT INTO `countries` VALUES (78, 'Ecuador', 'ecuador.gif');
INSERT INTO `countries` VALUES (79, 'Bahamas', 'bahamas.gif');
INSERT INTO `countries` VALUES (80, 'Peru', 'peru.gif');
INSERT INTO `countries` VALUES (81, 'Cambodia', 'cambodia.gif');
INSERT INTO `countries` VALUES (82, 'Barbados', 'barbados.gif');
INSERT INTO `countries` VALUES (83, 'Bangladesh', 'bangladesh.gif');
INSERT INTO `countries` VALUES (84, 'Laos', 'laos.gif');
INSERT INTO `countries` VALUES (85, 'Uruguay', 'uruguay.gif');
INSERT INTO `countries` VALUES (86, 'Antigua Barbuda', 'antiguabarbuda.gif');
INSERT INTO `countries` VALUES (87, 'Paraguay', 'paraguay.gif');
INSERT INTO `countries` VALUES (89, 'Thailand', 'thailand.gif');
INSERT INTO `countries` VALUES (88, 'Union of Soviet Socialist Republics', 'ussr.gif');
INSERT INTO `countries` VALUES (90, 'Senegal', 'senegal.gif');
INSERT INTO `countries` VALUES (91, 'Togo', 'togo.gif');
INSERT INTO `countries` VALUES (92, 'North Korea', 'northkorea.gif');
INSERT INTO `countries` VALUES (93, 'Croatia', 'croatia.gif');
INSERT INTO `countries` VALUES (94, 'Estonia', 'estonia.gif');
INSERT INTO `countries` VALUES (95, 'Colombia', 'colombia.gif');
INSERT INTO `countries` VALUES (96, 'Lebanon', 'lebanon.gif');
INSERT INTO `countries` VALUES (97, 'Latvia', 'latvia.gif');
INSERT INTO `countries` VALUES (98, 'Costa Rica', 'costarica.gif');
INSERT INTO `countries` VALUES (99, 'Egypt', 'egypt.gif');
INSERT INTO `countries` VALUES (100, 'Bulgaria', 'bulgaria.gif');
