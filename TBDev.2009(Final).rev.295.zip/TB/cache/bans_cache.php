<?php

$bans = array(
array('id'=> '1', 'first'=> -1062674722, 'last'=> -1062674722),

);

?>